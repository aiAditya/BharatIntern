const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const app = express();

app.use(express.json());
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));

mongoose.connect("mongodb://127.0.0.1:27017/Database")
  .then(() => {
    console.log("Connected to database");
  })
  .catch((err) => {
    console.error("Error connecting to database:", err);
  });
  var db=mongoose.connection
  
//   const collection = db.collection('users');
app.post("/signup", (req, res) => {
  const userData = {
    username: req.body.username,
    email: req.body.email,
    password: req.body.password,
  };

  
 db.collection('users').insertOne(userData, (err, result) => {
   if(err) {
    throw err;
   }
console.log("User registered:");
});
res.sendFile(__dirname + "/public/signup.html");
  
});

app.get("/", (req, res) => {
  return res.redirect("index.html");
});

app.listen(3000, () => {
  console.log("app listening on port no 3000");
});
